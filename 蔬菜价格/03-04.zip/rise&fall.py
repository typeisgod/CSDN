# -*- coding: utf-8 -*-
"""
Created on Sun Mar 25 13:46:15 2018

@author: 71405
"""
'''
part 2
生成涨跌分布图
单元格类似同上
1表示价格同比上一日增长
0 表示不变
-1表示跌
其中 数据丢失的取前几日的值（如果前几日均丢失则取后几日的值）
'''
import xlrd;
import xlwt;
workbook=xlrd.open_workbook(r'D:\大数据分析\03-04\蔬菜价格94.xls')
workspace=xlwt.Workbook(encoding='ascii')
booksheet=workbook.sheet_by_index(0)
createsheet=workspace.add_sheet('蔬菜价格',cell_overwrite_ok=True)
ri=0
rj=0
wi=0
wj=0
while ri<475:
    createsheet.write(ri,0,booksheet.cell_value(ri,0))
    ri=ri+1

while rj<64:
    createsheet.write(0,rj,booksheet.cell_value(0,rj))
    rj=rj+1
#生成横纵表头
ri=2;
rj=1;    
while ri<475:
    rj=1
    while rj<64:
        d=booksheet.cell_value(ri,rj)-booksheet.cell_value(ri-1,rj)
        if d>0:
            createsheet.write(ri,rj,1)
        if d<0:
            createsheet.write(ri,rj,-1)
        if d==0:
            createsheet.write(ri,rj,0)
        rj=rj+1
    ri=ri+1
    
workspace.save('蔬菜价格95.xls')