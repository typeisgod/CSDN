# -*- coding: utf-8 -*-
"""
Created on Sat Mar 24 23:14:19 2018

@author: Type真是太帅了
"""
'''
part 1
整理表格
'''
import xlrd;
import xlwt;
workbook=xlrd.open_workbook(r'D:\大数据分析\03-04\蔬菜价格3.xls')
workspace=xlwt.Workbook(encoding='ascii')
booksheet=workbook.sheet_by_index(0)
createsheet=workspace.add_sheet('蔬菜价格',cell_overwrite_ok=True)
createsheet.write(0,0,'日期')

ri=2 #遍历原始第i行
rj=0#遍历原始第i列
wi=0#写入表格的第k行
wj=1
#创建表头
while ri<45:
    rj=0
    while rj<5:
        if rj%2==1:
            if booksheet.cell_value(ri,rj)!='':
                createsheet.write(0,wj,booksheet.cell_value(ri,rj))
                wj=wj+1
        rj=rj+1
    ri=ri+1
ri=48 #遍历原始第i行
rj=0#遍历原始第i列
wi=0#写入表格的第k行
wj=1

while ri<22326:
    if ri%47==1:#新的一天
        wi=wi+1
        createsheet.write(wi,0,booksheet.cell_value(ri,0))
    else:
        rj=1
        while rj<5:
            if rj%2==1:
                if booksheet.cell_value(ri,rj)!='':
                    #print(booksheet.cell_value(ri,rj+1))
                    if booksheet.cell_value(ri,rj+1)!='':
                        createsheet.write(wi,wj,booksheet.cell_value(ri,rj+1))
                    wj=wj%63+1
            rj=rj+1
    ri=ri+1
workspace.save('蔬菜价格11.xls')#生成表格1  每个行表示日期  列表示货品  单元格表示价格


'''
part 2
生成涨跌分布图
单元格类似同上
1表示价格同比上一日增长
0 表示不变
-1表示跌
其中 数据丢失的取前几日的值（如果前几日均丢失则取后几日的值）
'''
