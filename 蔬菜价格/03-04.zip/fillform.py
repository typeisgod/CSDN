# -*- coding: utf-8 -*-
"""
Created on Sun Mar 25 14:05:45 2018

@author: 71405
"""
'''填充表格中的空缺部分
取前几日的值
如果前几日均丢失则取后几日的值
如果均丢失则恒为0
'''
import xlrd;
import xlwt;
workbook=xlrd.open_workbook(r'D:\大数据分析\03-04\蔬菜价格93.xls')
workspace=xlwt.Workbook(encoding='ascii')
booksheet=workbook.sheet_by_index(0)
createsheet=workspace.add_sheet('蔬菜价格',cell_overwrite_ok=True)

ri=1
while ri<475:
    rj=0
    while rj<64:
        if booksheet.cell_value(ri,rj)!='':
            createsheet.write(ri,rj,booksheet.cell_value(ri,rj))
        else:
            print(ri,rj)
            print('fuck ')
            i=ri
            tmp=0 #判断是否找到
            while i>0:
                if booksheet.cell_value(i,rj)!='':
                    tmp=1
                    createsheet.write(ri,rj,booksheet.cell_value(i,rj))
                    break
                i=i-1
            if tmp==0:
                i=ri
                while i<475:
                    if booksheet.cell_value(i,rj)!='':
                        tmp=1
                        createsheet.write(ri,rj,booksheet.cell_value(i,rj))
                       # print(2)
                        break
                    i=i+1
                if tmp==0:
                    createsheet.write(ri,rj,0)
                  #  print(3)
                  
        rj=rj+1
    ri=ri+1
rj=0;
while rj<64:
    createsheet.write(0,rj,booksheet.cell_value(0,rj))
    rj=rj+1
workspace.save('蔬菜价格94.xls')