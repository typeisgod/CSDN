import xlrd;
import xlwt;
workbook=xlrd.open_workbook(r'D:\大数据分析\03-04\蔬菜价格2.xls')
workspace=xlwt.Workbook(encoding='ascii')
booksheet=workbook.sheet_by_index(0)
createsheet=workspace.add_sheet('蔬菜价格',cell_overwrite_ok=True)

ri=1
rj=1
while ri<475:
    rj=0
    while rj<64:
        if booksheet.cell_value(ri,rj)=='\u3000' or ' ':
            createsheet.write(ri,rj,'')
        else:
            createsheet.write(ri,rj,booksheet.cell_value(ri,rj))
        rj=rj+1
    ri=ri+1
rj=0;
while rj<64:
    createsheet.write(0,rj,booksheet.cell_value(0,rj))
    rj=rj+1
workspace.save('蔬菜价格1.xls')            